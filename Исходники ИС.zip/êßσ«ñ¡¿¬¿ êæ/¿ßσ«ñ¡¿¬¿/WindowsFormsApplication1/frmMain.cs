﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "ermoDataSet.Постояльцы". При необходимости она может быть перемещена или удалена.
            this.постояльцыTableAdapter.Fill(this.ermoDataSet.Постояльцы);
            (new frmLogon()).ShowDialog(this);//главной формой является эта форма, frmMain
        }

        private void базыДанныхToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            постояльцыTableAdapter.Update(ermoDataSet);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void сотрудникиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sotrud sf = new sotrud();
            sf.Owner = this;
            sf.Show();
        }

        private void номераToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nomer sf = new nomer();
            sf.Owner = this;
            sf.Show();
        }

        private void руководствоToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Для того чтобы сделать запись в базе данных нажмите на пустую строку в таблице и введите нужные значения, после чего обязательно нажмите кнопку СОХРАНИТЬ");
        }

        private void авторскиеПраваToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Программа создана для отеля Элеон, разработчиком является Ермолаев В.А");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Poisk1 sf = new Poisk1();
            sf.Owner = this;
            sf.Show();
        }
    }
}
