﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class sotrud : Form
    {
        public sotrud()
        {
            InitializeComponent();
        }

        private void sotrud_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "ermoDataSet.Сотрудники". При необходимости она может быть перемещена или удалена.
            this.сотрудникиTableAdapter.Fill(this.ermoDataSet.Сотрудники);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
