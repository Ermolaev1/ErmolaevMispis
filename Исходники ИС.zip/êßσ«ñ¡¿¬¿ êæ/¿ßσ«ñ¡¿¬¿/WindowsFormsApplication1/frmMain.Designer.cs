﻿namespace WindowsFormsApplication1
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.базыДанныхToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сотрудникиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.номераToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.руководствоToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.авторскиеПраваToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.кодПостольцаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фИОDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерПроживанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.посуточнаяСтоимостьDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.суммаОплатыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаЗаселенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.обслуживающаяГорничнаяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.постояльцыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ermoDataSet = new WindowsFormsApplication1.ErmoDataSet();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.постояльцыTableAdapter = new WindowsFormsApplication1.ErmoDataSetTableAdapters.ПостояльцыTableAdapter();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.постояльцыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ermoDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.базыДанныхToolStripMenuItem,
            this.справкаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(960, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // базыДанныхToolStripMenuItem
            // 
            this.базыДанныхToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сотрудникиToolStripMenuItem,
            this.номераToolStripMenuItem});
            this.базыДанныхToolStripMenuItem.Name = "базыДанныхToolStripMenuItem";
            this.базыДанныхToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
            this.базыДанныхToolStripMenuItem.Text = "Базы данных";
            this.базыДанныхToolStripMenuItem.Click += new System.EventHandler(this.базыДанныхToolStripMenuItem_Click);
            // 
            // сотрудникиToolStripMenuItem
            // 
            this.сотрудникиToolStripMenuItem.Name = "сотрудникиToolStripMenuItem";
            this.сотрудникиToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.сотрудникиToolStripMenuItem.Text = "Сотрудники";
            this.сотрудникиToolStripMenuItem.Click += new System.EventHandler(this.сотрудникиToolStripMenuItem_Click);
            // 
            // номераToolStripMenuItem
            // 
            this.номераToolStripMenuItem.Name = "номераToolStripMenuItem";
            this.номераToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.номераToolStripMenuItem.Text = "Номера";
            this.номераToolStripMenuItem.Click += new System.EventHandler(this.номераToolStripMenuItem_Click);
            // 
            // справкаToolStripMenuItem
            // 
            this.справкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.руководствоToolStripMenuItem,
            this.авторскиеПраваToolStripMenuItem});
            this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            this.справкаToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.справкаToolStripMenuItem.Text = "Справка";
            // 
            // руководствоToolStripMenuItem
            // 
            this.руководствоToolStripMenuItem.Name = "руководствоToolStripMenuItem";
            this.руководствоToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.руководствоToolStripMenuItem.Text = "Руководство";
            this.руководствоToolStripMenuItem.Click += new System.EventHandler(this.руководствоToolStripMenuItem_Click);
            // 
            // авторскиеПраваToolStripMenuItem
            // 
            this.авторскиеПраваToolStripMenuItem.Name = "авторскиеПраваToolStripMenuItem";
            this.авторскиеПраваToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.авторскиеПраваToolStripMenuItem.Text = "Авторские права";
            this.авторскиеПраваToolStripMenuItem.Click += new System.EventHandler(this.авторскиеПраваToolStripMenuItem_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодПостольцаDataGridViewTextBoxColumn,
            this.фИОDataGridViewTextBoxColumn,
            this.номерПроживанияDataGridViewTextBoxColumn,
            this.посуточнаяСтоимостьDataGridViewTextBoxColumn,
            this.суммаОплатыDataGridViewTextBoxColumn,
            this.датаЗаселенияDataGridViewTextBoxColumn,
            this.обслуживающаяГорничнаяDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.постояльцыBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(81, 168);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(406, 275);
            this.dataGridView1.TabIndex = 1;
            // 
            // кодПостольцаDataGridViewTextBoxColumn
            // 
            this.кодПостольцаDataGridViewTextBoxColumn.DataPropertyName = "Код постольца";
            this.кодПостольцаDataGridViewTextBoxColumn.HeaderText = "Код постольца";
            this.кодПостольцаDataGridViewTextBoxColumn.Name = "кодПостольцаDataGridViewTextBoxColumn";
            // 
            // фИОDataGridViewTextBoxColumn
            // 
            this.фИОDataGridViewTextBoxColumn.DataPropertyName = "ФИО";
            this.фИОDataGridViewTextBoxColumn.HeaderText = "ФИО";
            this.фИОDataGridViewTextBoxColumn.Name = "фИОDataGridViewTextBoxColumn";
            // 
            // номерПроживанияDataGridViewTextBoxColumn
            // 
            this.номерПроживанияDataGridViewTextBoxColumn.DataPropertyName = "Номер проживания";
            this.номерПроживанияDataGridViewTextBoxColumn.HeaderText = "Номер проживания";
            this.номерПроживанияDataGridViewTextBoxColumn.Name = "номерПроживанияDataGridViewTextBoxColumn";
            // 
            // посуточнаяСтоимостьDataGridViewTextBoxColumn
            // 
            this.посуточнаяСтоимостьDataGridViewTextBoxColumn.DataPropertyName = "Посуточная стоимость";
            this.посуточнаяСтоимостьDataGridViewTextBoxColumn.HeaderText = "Посуточная стоимость";
            this.посуточнаяСтоимостьDataGridViewTextBoxColumn.Name = "посуточнаяСтоимостьDataGridViewTextBoxColumn";
            // 
            // суммаОплатыDataGridViewTextBoxColumn
            // 
            this.суммаОплатыDataGridViewTextBoxColumn.DataPropertyName = "Сумма оплаты";
            this.суммаОплатыDataGridViewTextBoxColumn.HeaderText = "Сумма оплаты";
            this.суммаОплатыDataGridViewTextBoxColumn.Name = "суммаОплатыDataGridViewTextBoxColumn";
            // 
            // датаЗаселенияDataGridViewTextBoxColumn
            // 
            this.датаЗаселенияDataGridViewTextBoxColumn.DataPropertyName = "Дата заселения";
            this.датаЗаселенияDataGridViewTextBoxColumn.HeaderText = "Дата заселения";
            this.датаЗаселенияDataGridViewTextBoxColumn.Name = "датаЗаселенияDataGridViewTextBoxColumn";
            // 
            // обслуживающаяГорничнаяDataGridViewTextBoxColumn
            // 
            this.обслуживающаяГорничнаяDataGridViewTextBoxColumn.DataPropertyName = "Обслуживающая горничная";
            this.обслуживающаяГорничнаяDataGridViewTextBoxColumn.HeaderText = "Обслуживающая горничная";
            this.обслуживающаяГорничнаяDataGridViewTextBoxColumn.Name = "обслуживающаяГорничнаяDataGridViewTextBoxColumn";
            // 
            // постояльцыBindingSource
            // 
            this.постояльцыBindingSource.DataMember = "Постояльцы";
            this.постояльцыBindingSource.DataSource = this.ermoDataSet;
            // 
            // ermoDataSet
            // 
            this.ermoDataSet.DataSetName = "ErmoDataSet";
            this.ermoDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.Color.Brown;
            this.button1.Location = new System.Drawing.Point(612, 168);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(164, 71);
            this.button1.TabIndex = 2;
            this.button1.Text = "Сохранить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.ForeColor = System.Drawing.Color.Brown;
            this.button2.Location = new System.Drawing.Point(612, 260);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(164, 71);
            this.button2.TabIndex = 3;
            this.button2.Text = "Поиск";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.ForeColor = System.Drawing.Color.Brown;
            this.button3.Location = new System.Drawing.Point(612, 372);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(164, 71);
            this.button3.TabIndex = 4;
            this.button3.Text = "Выход";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // постояльцыTableAdapter
            // 
            this.постояльцыTableAdapter.ClearBeforeFill = true;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(960, 540);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.Text = "ErmoLion";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.постояльцыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ermoDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem базыДанныхToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сотрудникиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem номераToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem руководствоToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem авторскиеПраваToolStripMenuItem;
        public System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        public ErmoDataSet ermoDataSet;
        public System.Windows.Forms.BindingSource постояльцыBindingSource;
        public ErmoDataSetTableAdapters.ПостояльцыTableAdapter постояльцыTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодПостольцаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерПроживанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn посуточнаяСтоимостьDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn суммаОплатыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаЗаселенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn обслуживающаяГорничнаяDataGridViewTextBoxColumn;
    }
}