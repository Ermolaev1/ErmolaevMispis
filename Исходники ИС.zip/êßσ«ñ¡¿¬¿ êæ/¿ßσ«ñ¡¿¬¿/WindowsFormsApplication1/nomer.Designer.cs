﻿
namespace WindowsFormsApplication1
{
    partial class nomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(nomer));
            this.button3 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ermoDataSet = new WindowsFormsApplication1.ErmoDataSet();
            this.номераBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.номераTableAdapter = new WindowsFormsApplication1.ErmoDataSetTableAdapters.НомераTableAdapter();
            this.кодНомераDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.комнатВНомереDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кроватейВНомереDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.дополнительныеУслугиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ermoDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.номераBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.ForeColor = System.Drawing.Color.Brown;
            this.button3.Location = new System.Drawing.Point(543, 216);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(164, 71);
            this.button3.TabIndex = 6;
            this.button3.Text = "Выход";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодНомераDataGridViewTextBoxColumn,
            this.комнатВНомереDataGridViewTextBoxColumn,
            this.кроватейВНомереDataGridViewTextBoxColumn,
            this.дополнительныеУслугиDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.номераBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(406, 275);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // ermoDataSet
            // 
            this.ermoDataSet.DataSetName = "ErmoDataSet";
            this.ermoDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // номераBindingSource
            // 
            this.номераBindingSource.DataMember = "Номера";
            this.номераBindingSource.DataSource = this.ermoDataSet;
            // 
            // номераTableAdapter
            // 
            this.номераTableAdapter.ClearBeforeFill = true;
            // 
            // кодНомераDataGridViewTextBoxColumn
            // 
            this.кодНомераDataGridViewTextBoxColumn.DataPropertyName = "Код номера";
            this.кодНомераDataGridViewTextBoxColumn.HeaderText = "Код номера";
            this.кодНомераDataGridViewTextBoxColumn.Name = "кодНомераDataGridViewTextBoxColumn";
            // 
            // комнатВНомереDataGridViewTextBoxColumn
            // 
            this.комнатВНомереDataGridViewTextBoxColumn.DataPropertyName = "Комнат в номере";
            this.комнатВНомереDataGridViewTextBoxColumn.HeaderText = "Комнат в номере";
            this.комнатВНомереDataGridViewTextBoxColumn.Name = "комнатВНомереDataGridViewTextBoxColumn";
            // 
            // кроватейВНомереDataGridViewTextBoxColumn
            // 
            this.кроватейВНомереDataGridViewTextBoxColumn.DataPropertyName = "Кроватей в номере";
            this.кроватейВНомереDataGridViewTextBoxColumn.HeaderText = "Кроватей в номере";
            this.кроватейВНомереDataGridViewTextBoxColumn.Name = "кроватейВНомереDataGridViewTextBoxColumn";
            // 
            // дополнительныеУслугиDataGridViewTextBoxColumn
            // 
            this.дополнительныеУслугиDataGridViewTextBoxColumn.DataPropertyName = "Дополнительные услуги";
            this.дополнительныеУслугиDataGridViewTextBoxColumn.HeaderText = "Дополнительные услуги";
            this.дополнительныеУслугиDataGridViewTextBoxColumn.Name = "дополнительныеУслугиDataGridViewTextBoxColumn";
            // 
            // nomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(722, 304);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.dataGridView1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "nomer";
            this.Text = "Номер";
            this.Load += new System.EventHandler(this.nomer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ermoDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.номераBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private ErmoDataSet ermoDataSet;
        private System.Windows.Forms.BindingSource номераBindingSource;
        private ErmoDataSetTableAdapters.НомераTableAdapter номераTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодНомераDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn комнатВНомереDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кроватейВНомереDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn дополнительныеУслугиDataGridViewTextBoxColumn;
    }
}